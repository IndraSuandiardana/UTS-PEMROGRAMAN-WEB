<template>
  <div class="hero">
    <!-- Dekstop -->
    <div class="d-none d-md-block">
      <div class="row nt-4">
        <div class="col-md-6">
          <div class="d-flex h-100">
            <div class="justify-content-center align-self-center">
              <h2>
                <strong>Pure Incense,</strong><br />Scent From Another World
              </h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint
                cupiditate voluptatem dolorum vero eum voluptatibus nulla
                consequatur aperiam exercitationem excepturi!
              </p>
              <router-link class="btn btn-lg btn-success" to="/products">
                <b-icon-arrow-right></b-icon-arrow-right>Order
              </router-link>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <img src="../assets/Images/Hero.png" width="100%" />
        </div>
      </div>
    </div>

    <!-- Mobile -->
    <div class="d-sm-block d-md-none">
      <div class="row nt-4">
        <div class="col-md-6">
          <img src="../assets/Images/Hero.png" width="100%" />
        </div>
        <div class="col-md-6">
          <div class="d-flex h-100">
            <div class="justify-content-center align-self-center">
              <h2>
                <strong>Pure Incense,</strong><br />Scent From Another World
              </h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint
                cupiditate voluptatem dolorum vero eum voluptatibus nulla
                consequatur aperiam exercitationem excepturi!
              </p>
              <router-link class="btn btn-lg btn-success" to="/products">
                <b-icon-arrow-right></b-icon-arrow-right>Order
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Hero",
};
</script>

<style>
</style>