<template>
  <div class="product-detail">
    <navbar />
    <div class="container">
      <!-- breadcrumb -->
      <div class="row mt-5">
        <div class="col">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <router-link to="/" class="text-dark">Home</router-link>
              </li>
              <li class="breadcrumb-item">
                <router-link to="/products" class="text-dark"
                  >Products</router-link
                >
              </li>
              <li class="breadcrumb-item active" aria-current="page">
                Product Order
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div class="row mt-3">
          <div class="col-md-6">
              <img  :src="'../assets/Images/' + product.image" class="img-fluid shadow" />
          </div>
          <div class="col-md-6">
              <h2><strong>{{ product.name }}</strong></h2>
              <hr/>
              <h4>Price <strong>Rp. {{product.price}}</strong></h4>
              <form class="nt-4 v-on:submit.prevent">
                  <div class="form-group">
                      <label for="order_quantity">Order Quantity</label>
                      <input type="number" class="form-control" v-model="order.Order_Quantity" />
                  </div>
                  <div class="form-group">
                      <label for="description">Description</label>
                      <textarea
                      v-model="order.description"
                       class="form-control" placeholder="Description example : meditation...etc"></textarea>
                  </div>
                  <button type="submit" class="btn btn-success" I @click="ordering"><b-icon-cart></b-icon-cart>Order</button>
              </form>
          </div>
      </div>
    </div>
  </div>
</template>

<script>
import Navbar from "@/components/Navbar.vue";
import axios from 'axios';

export default {
  name: "ProductDetail",
  components: {
    Navbar,
  },
  data(){
      return {
          product: {},
          order: {}
      }
  },
  methods: {
      setProduct(data){
          this.product = data
      },
      ordering() {
        this.order.products = this.product;
        axios
        .post("http://localhost:3000/Cart", this.order)
        .then (() => {
          console.log("Success");
        })
        .catch((error) => console.log(error))
      }
  },
  mounted(){
      axios
      .get("http://localhost:3000/products/"+this.$route.params.id)
      .then((response) => this.setProduct(response.data))
      .catch((error) => console.log(error));
  }
};
</script>

<style>
</style>